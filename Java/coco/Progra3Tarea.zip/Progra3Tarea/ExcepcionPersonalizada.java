public class ExcepcionPersonalizada extends Exception {
// manejo de excepciones personalizadas
	public ExcepcionPersonalizada(String mensaje) {
		super(mensaje);
	}
}
