package Arbol_2017;

public class NodoArbol1 {
    public static void main(String[] args)  {
        System.out.println("hola mundo");

    }
}
