package Arbol_2017;

public class Principal {
	public static void main(String[] args) {
		ArbolBinario arbol = new ArbolBinario();

		arbol.insertarNodo(20);
		arbol.insertarNodo(20);
		arbol.insertarNodo(20);
		arbol.insertarNodo(20);
		arbol.insertarNodo(20);
		arbol.insertarNodo(20);

	}
}
